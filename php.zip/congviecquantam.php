<?php include('header.php') ?>
<header>
        <div class="container-fluid">
            <div class="row header1">
                <div class="col-md-2 logo">
                    <img class="img-responsive" src="assets/img/banner-cpit.png" width="300">
                </div>
                <div class="col-md-6 search">
                    <div class="tenviec">
                        <div class="form-group inputtimkiem col-md-5">
                            <label for="usr">Tên việc làm:</label>
                            <input type="text" class="form-control" id="usr">
                        </div>
                        <div class="form-group inputtimkiem col-md-5">
                            <label for="usr">Địa điểm:</label>
                            <input type="text" class="form-control" id="usr">
                        </div>
                        <div class="inputsearch">
                            <button class="btn btn-success" type="submit"><i class="glyphicon glyphicon-search"></i></button>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-4">
                    <div class="btn-group lienket" role="group"><a class="btn btn-link" role="button" href="hosodoanhnghiep.html">Hồ sơ doanh nghiệp</a><a class="btn btn-info" role="button" href="dangkytuyendung.html">Nhà tuyển dụng</a></div>
                </div>
            </div>
        </div>
    </header>

<div class="text-center">    
  <h3>Công việc đã quan tâm</h3><br>
  <div class="row">
      <div class="col-sm-4">
        <div class="auto-style1">
     <a href="#"> + Tên Công việc: Cổng Thông Tin Điện Tử&nbsp;&nbsp;&nbsp;</a> <br />
    + Tên Công ty đăng: Công ty CỔ Phần CPIT<br />
    + Giá trị: <br />
    + Địa điểm: Hà Nội<br />
    + Tình trạng: Đã chào giá<br />
     </div>
    </div>
      <div class="col-sm-4">
        <div class="auto-style1">
     <a href="#"> + Tên Công việc: Cổng Thông Tin Điện Tử&nbsp;&nbsp;&nbsp;</a> <br />
    + Tên Công ty đăng: Công ty CỔ Phần CPIT<br />
    + Giá trị: <br />
    + Địa điểm: Hà Nội<br />
    + Tình trạng: Đã chào giá<br />
     </div>
    </div>
    <div class="col-sm-4">
        <div class="auto-style1">
     <a href="#"> + Tên Công việc: Cổng Thông Tin Điện Tử&nbsp;&nbsp;&nbsp;</a> <br />
    + Tên Công ty đăng: Công ty CỔ Phần CPIT<br />
    + Giá trị: <br />
    + Địa điểm: Hà Nội<br />
    + Tình trạng: Đã chào giá<br />
     </div>
    </div>
    <div class="col-sm-4"> 
        <div class="auto-style2">
     <a href="#"> + Tên Công việc: Cổng Thông Tin Điện Tử&nbsp;&nbsp;&nbsp;</a> <br />
    + Tên Công ty đăng: Công ty CỔ Phần CPIT<br />
    + Giá trị: <br />
    + Địa điểm: Hà Nội<br />
    + Tình trạng: Đã chào giá<br />
      </div>
    </div>
       <div class="col-sm-4"> 
        <div class="auto-style2">
     <a href="#"> + Tên Công việc: Cổng Thông Tin Điện Tử&nbsp;&nbsp;&nbsp;</a> <br />
    + Tên Công ty đăng: Công ty CỔ Phần CPIT<br />
    + Giá trị: <br />
    + Địa điểm: Hà Nội<br />
    + Tình trạng: Đã chào giá<br />
      </div>
    </div>
       <div class="col-sm-4"> 
        <div class="auto-style2">
     <a href="#"> + Tên Công việc: Cổng Thông Tin Điện Tử&nbsp;&nbsp;&nbsp;</a> <br />
    + Tên Công ty đăng: Công ty CỔ Phần CPIT<br />
    + Giá trị: <br />
    + Địa điểm: Hà Nội<br />
    + Tình trạng: Đã chào giá<br />
      </div>
    </div>
   
    </div>
  
    
</div><br>
  
   <div class=" text-center"><< <a>1</a> 2 3<a>>></a> </div>
    <form id="form1" runat="server">
        <asp:Button ID="Button1" runat="server" Text="Quay Lại" BackColor="#CCCCCC" BorderColor="Gray" ForeColor="White"  />
    </form>
 

<?php include('footer.php') ?>