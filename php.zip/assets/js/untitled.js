$("#advanceSearchToggle").click(function() {
    $("#advanceSearch").slideToggle();
})